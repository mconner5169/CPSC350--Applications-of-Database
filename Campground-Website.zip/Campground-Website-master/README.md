# CPSC 350 - Campground Website

Created the frontend of a website that can search for campgrounds in the Postman database, display it's location, a description, and
provide a picture of the campground.

This project includes JavaScript.
